﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eventures.Web.ViewModels
{
    public class ErrorMessageViewModel
    {
        public string ErrorMessage { get; set; }
    }
}
