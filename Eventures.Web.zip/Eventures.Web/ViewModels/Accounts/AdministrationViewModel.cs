﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eventures.Web.ViewModels.Accounts
{
    public class AdministrationViewModel
    {
       public string UserId { get; set; }

        public string CurrentRole { get; set; }

    }
}
